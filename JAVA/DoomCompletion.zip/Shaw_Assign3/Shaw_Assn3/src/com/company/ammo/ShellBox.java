package com.company.ammo;

import com.company.ammo.AmmoItem;

/** Box of Shells Class */
public class ShellBox extends AmmoItem {

    //Constructor for She
    public  ShellBox(){
        name = "Box of Shells";
        ammoAmount = 20;
        ammoType = 1;
    }
}