package com.company.ammo;

import com.company.ammo.AmmoItem;

/**Clip Class */

public class Clip extends AmmoItem {

    //Constructor for Clip
    public Clip (){
        name = "Clip";
        ammoAmount = 10;
        ammoType = 0;

    }
}