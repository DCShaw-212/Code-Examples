package com.company.ammo;


import com.company.ammo.AmmoItem;

/** Box Of Bullets Class */
public class BulletBox extends AmmoItem {
    //Constructor for BoxOfBullets
    public BulletBox (){
        name = "Bullet Box";
        ammoAmount = 50;
        ammoType = 0;

    }
}

