package com.company.ammo;

import com.company.ammo.AmmoItem;

/** Cell Pack Class*/
public class CellPack extends AmmoItem {

    //Constructor for CellPack
    public CellPack(){
        name = "Cell Pack";
        ammoAmount = 100;
        ammoType = 3;
    }
}
