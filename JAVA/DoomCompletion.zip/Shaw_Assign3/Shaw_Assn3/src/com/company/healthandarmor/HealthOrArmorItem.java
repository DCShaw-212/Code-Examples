package com.company.healthandarmor;

//This is the beginning of the health and armor item classes

import com.company.Item.Item;

/**SuperClass HealthOrArmorItem*/
public class HealthOrArmorItem extends Item{

    public boolean pickUpItem(){
        return true;
    }

}






