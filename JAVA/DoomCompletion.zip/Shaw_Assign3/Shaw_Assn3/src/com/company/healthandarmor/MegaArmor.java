package com.company.healthandarmor;

import com.company.healthandarmor.ArmorItem;

public class MegaArmor extends ArmorItem {

    //Constructor for Mega Armor
    public MegaArmor(){
        name = "Mega Armor";
        armorAmount = 200;
    }
}
