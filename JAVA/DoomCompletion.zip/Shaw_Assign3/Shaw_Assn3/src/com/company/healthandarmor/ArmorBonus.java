package com.company.healthandarmor;

import com.company.healthandarmor.ArmorItem;

/**SubClass ArmorBonus*/
public class ArmorBonus extends ArmorItem {
    //Constructor for Armor Bonus
    public ArmorBonus(){
        name = "Armor Bonus";
        armorAmount = 1;
    }
}
