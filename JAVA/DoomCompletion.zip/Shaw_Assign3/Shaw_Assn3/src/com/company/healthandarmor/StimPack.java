package com.company.healthandarmor;

import com.company.healthandarmor.HealthItem;

/**This is the class for Stimpack*/
public class StimPack extends HealthItem {

    //Constructor for Stimpack
    public StimPack(){
        name = "Stimpack";
        healthAmount = 10;
    }

}
