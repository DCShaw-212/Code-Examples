package com.company.healthandarmor;

import com.company.healthandarmor.HealthItem;

/**This is the class for health bonus */
public class HealthBonus extends HealthItem {

    //Constructor for Health Bonus
    public HealthBonus(){
        name = "Health Bonus";
        healthAmount = 1;
    }
}
