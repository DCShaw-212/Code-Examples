package com.company.healthandarmor;


import com.company.healthandarmor.HealthItem;

/** This is the soul sphere class item */
public class SoulSphere extends HealthItem {

    //Constructor for SoulSphere
    public SoulSphere(){
        name = "Soul Sphere";
        healthAmount = 200;
    }
}
