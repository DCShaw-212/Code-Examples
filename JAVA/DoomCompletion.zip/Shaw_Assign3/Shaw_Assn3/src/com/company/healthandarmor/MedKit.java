package com.company.healthandarmor;


import com.company.healthandarmor.HealthItem;

/**This is the class for MedKit*/
public class MedKit extends HealthItem {

    //Constructor for Medkit
    public MedKit(){
        name = "Medkit";
        healthAmount = 25;
    }

}
