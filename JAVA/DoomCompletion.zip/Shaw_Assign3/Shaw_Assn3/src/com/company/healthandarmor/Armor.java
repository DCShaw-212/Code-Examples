package com.company.healthandarmor;

import com.company.healthandarmor.ArmorItem;

/**subclass Armor */
public class Armor extends ArmorItem {
    //Constructor for Armor
    public Armor(){
        name = "Armor";
        armorAmount = 100;
    }
}
